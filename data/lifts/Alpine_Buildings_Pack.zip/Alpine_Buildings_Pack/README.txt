OOF'S ALPINE BUILDINGS  --  building pack for Ski-E-O! Ski Resort Tycoon
=========================================================================

50 new buildings for your resort, all made from scratch for this pack out of the game's own
materials: wood, stone, metal roofs, and windows that light up at night. Every one has doors at its
entrances (the big ones on the front and the sides) and its own snow cap, like the game's own
buildings: snow on everything open to the sky.

In the build menu they have plain names, numbered per kind: Cabin 1-29, Hotel 1-18, Base Lodge 1-3.
Here is which is which:

CABINS  (single-family homes: guests stay in them like the game's Cabin, one family each)
  Cabin 1         Timber Frame Chalet         glazed gable, glass balcony, stone chimney                  4 beds
  Cabin 2         Timber Frame Lodge Home     L-shaped, log wing, timber balcony                          4 beds
  Cabin 3         Modern Shed-Roof Retreat    dark boards, mono-pitch roof, glass front                   4 beds
  Cabin 4         Glass Front Ski House       three storeys with a full glass front                       4 beds
  Cabin 5         Log & Glass Chalet          dark logs, shingled roof, glazed gable                      4 beds
  Cabin 6         Twin Gable Modern Home      white boards, two gables, glass balcony                     4 beds
  Cabin 7         Peak A-Frame                steep A-frame with a two-storey glass gable                 4 beds
  Cabin 8         Shed-Roof Ski House         mono-pitch roof and a log wing                              4 beds
  Cabin 9         Timber Ridge Walkout        timber-frame walkout home, stone chimney, covered deck      4 beds
  Cabin 10        Aspen Timber Home           stone walkout level, covered deck, twin trussed dormers     4 beds
  Cabin 11        River Rock Timber Home      heavy-truss portico on river-rock columns, rusty awnings    4 beds
  Cabin 12        Stone Gate Timber Home      trussed portico on stone columns, copper-red roof           4 beds
  Cabin 13        Black Bear Timber Home      black timber on stone, red metal roof, iron-railed deck     4 beds
  Cabin 14        Elk Ridge Timber Home       long red-timber home, green metal roof                      4 beds
  Cabin 15        Granite Peak Timber Home    cream timber, stone-column portico, rusty awnings           4 beds
  Cabin 16        Trapper Log Cabin           small rustic log cabin with a front porch                   4 beds
  Cabin 17        Creekside Log Home          L-shaped log home, wraparound porch, green roof             4 beds
  Cabin 18        Bear Den Log Lodge          big log home with a log-column portico                      4 beds
  Cabin 19        Classic A-Frame             true A-frame with a glazed gable and a deck                 4 beds
  Cabin 20        Twin Peaks A-Frame          two A-frames joined by an entry link                        4 beds
  Cabin 21        Bernese Chalet              Swiss chalet with deep eaves and balconies all round        4 beds
  Cabin 22        Engadin Stone Chalet        stone and render village house with a barn door             4 beds
  Cabin 23        Edelweiss Guesthouse        big four-storey chalet guesthouse                           4 beds
  Cabin 24        Ski-In Townhouses           three attached townhouses                                   4 beds
  Cabin 25        Village Row Houses          four attached row houses                                    4 beds
  Cabin 26        Larch Cube Villa            stacked larch boxes, cantilever, roof terrace               4 beds
  Cabin 27        Glass Gable House           minimalist gable with a fully glazed end                    4 beds
  Cabin 28        Stone & Glass Retreat       long low stone house with walls of glass                    4 beds
  Cabin 29        Split-Level Modern Home     two offset shed-roof volumes                                4 beds

HOTELS  (work like the game's Hotel)
  Hotel 1         Timberline Grand Lodge      stone base, dark timber, dormers, porte-cochere           170 guests
  Hotel 2         Snowmass Inn                L-shaped stucco and stone inn                             190 guests
  Hotel 3         Summit Tower Lodge          three wings and a tower                                   265 guests
  Hotel 4         Twin Tower Log Lodge        long log lodge with a tower at each end                   190 guests
  Hotel 5         Alpine Grand Hotel          T-shaped stucco grand hotel                               185 guests
  Hotel 6         Red Timber Resort Hotel     stepped three-wing hotel in red timber                    200 guests
  Hotel 7         Charcoal Peak Lodge         charcoal timber with a central tower                      170 guests
  Hotel 8         Grand Summit Lodge          giant grand lodge: glazed great hall, cross-gabled wings  450 guests
  Hotel 9         Grand Alpine Palace Hotel   giant chateau hotel: copper roofs, turrets, portico       450 guests
  Hotel 10        Larch Balcony Hotel         long hotel with larch balconies, metal top floor          200 guests
  Hotel 11        Alpine Terrace Hotel        two hotel blocks joined by a glazed link                  260 guests
  Hotel 12        Snowline Design Hotel       three staggered blocks stepping up                        170 guests
  Hotel 13        Slopeside Apartments        modern apartment house                                     75 guests
  Hotel 14        Summit Residences           two apartment blocks of different heights                  90 guests
  Hotel 15        Eagle Ridge Grand Lodge     long log lodge, two towers, green roof                    265 guests
  Hotel 16        Highland Grand Lodge        U-shaped cream-timber lodge with a central tower          320 guests
  Hotel 17        Village Inn                 stone and timber inn with three trussed cross gables       50 guests
  Hotel 18        Ridgeview Condos            condo lodge of gabled bays with private balconies          50 guests

BASE LODGES  (work like the game's Base Lodge: food, rest and warmth for day skiers)
  Base Lodge 1    Canyon Lake Estate          timber pavilions on a stone terrace, glazed great room    120 guests
  Base Lodge 2    Timberline Lake Hotel       three-storey estate hotel, full glass great-room gable    195 guests
  Base Lodge 3    Silver Lake Estate          dark timber estate with a three-storey glass pavilion     130 guests

Cabins are single-family homes: 4 beds each, $30,400 to build and $152 a day to run (the game's own
30-bed Cabin: $152,000). Hotels and base lodges hold guests by their floor area, and building and
running one costs what the game's own building of the same kind costs, scaled with its guests, and
never more than 1.3 times that. They unlock like the game's own building of their kind and sell what
it sells (beds to rent; the base lodges food, drinks and hand warmers). No stock building is changed.

INSTALL
-------
This pack installs with the Ski-E-O Map Creator (version 1.5.0 or later), the only way to install it:
1. Close the game.
2. Open the Map Creator and click Mod Library at the bottom.
3. Click Install next to "Oof's Alpine Buildings".
4. Start the game: the new buildings are in the build menu next to the game's own Cabin, Hotel and
   Base Lodge.

The Map Creator keeps the pack working after game updates (each time it starts, it refreshes the
pack's copy of the game's building list from your own game files) and brings the pack up to date when
you update the app. Copying the pack's files into ~mods by hand is not supported.

It works together with the Doppelmayr D-Line R2 Six and R2 Gondola lift packs: install any of
them and you get all of their content.

UNINSTALL
---------
Mod Library > Uninstall (with the game closed). Take the pack's buildings out of your save first,
or they will be missing when you load.

NOTES
-----
- The two giants are very big (over 120 m long): give them a large, fairly flat spot.
- On the author's PC the game crashes once on the first launch after mod files are added or
  changed, then starts fine. If it happens, just launch the game again.
- A game update can break mods. If the game won't start after an update, uninstall the pack in
  the Mod Library.
- Other mods that also replace the building economy table (DT_BuildingEconomy) or the snow cap list
  (DA_SnowCapRegistry) can clash with this one.

CREDITS
-------
- Every building in this pack was made for it: modelled procedurally in Blender (our own
  generator) on the game's own materials. No downloaded models.
- Mod build: custom Blender / Unreal pipeline.
